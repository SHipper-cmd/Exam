namespace WindowsFormsApp4
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Licence")]
    public partial class Licence
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ID { get; set; }

        [Column(TypeName = "date")]
        public DateTime? licence_date { get; set; }

        [Column(TypeName = "date")]
        public DateTime? expire_date { get; set; }

        [StringLength(6)]
        public string categories { get; set; }

        [StringLength(4)]
        public string licence_series { get; set; }

        [StringLength(6)]
        public string licence_number { get; set; }

        [StringLength(10)]
        public string Status { get; set; }
    }
}
