using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace WindowsFormsApp4
{
    public partial class Model11 : DbContext
    {
        public Model11()
            : base("name=Model11")
        {
        }

        public virtual DbSet<Cars> Cars { get; set; }
        public virtual DbSet<Voditeli> Voditeli { get; set; }
        public virtual DbSet<Licence> Licence { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Licence>()
                .Property(e => e.Status)
                .IsFixedLength();
        }
    }
}
