namespace WindowsFormsApp4
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Voditeli")]
    public partial class Voditeli
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ID { get; set; }

        [StringLength(50)]
        public string Фамилия { get; set; }

        [StringLength(50)]
        public string Имя { get; set; }

        [StringLength(50)]
        public string Отчество { get; set; }

        public int? Серия_паспорта { get; set; }

        public int? Номер_паспорта { get; set; }

        public string Адрес_регистрации { get; set; }

        public string Адрес_проживания { get; set; }

        public string Место_работы { get; set; }

        [StringLength(50)]
        public string Должность { get; set; }

        [StringLength(50)]
        public string Мобильный_телефон { get; set; }

        [StringLength(50)]
        public string Email { get; set; }

        public byte[] Фотография { get; set; }

        public string Замечания { get; set; }
    }
}
