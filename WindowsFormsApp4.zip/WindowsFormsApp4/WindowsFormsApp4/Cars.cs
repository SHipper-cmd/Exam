namespace WindowsFormsApp4
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Cars
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ID { get; set; }

        [StringLength(50)]
        public string VIN { get; set; }

        [StringLength(50)]
        public string Manufacturer { get; set; }

        [StringLength(50)]
        public string Model { get; set; }

        public int? Year { get; set; }

        public int? Weight { get; set; }

        public int? Color { get; set; }

        public int? Engine_type { get; set; }

        [StringLength(50)]
        public string Type_of_drive { get; set; }
    }
}
